﻿using Microsoft.EntityFrameworkCore;
using SalonManagementSystem.Models;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<Salon> Salons { get; set; }
    public DbSet<Service> Services { get; set; }
    public DbSet<Employee> Employees { get; set; }
    public DbSet<Expertise> Expertises { get; set; }
    public DbSet<Appointment> Appointments { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

      

        modelBuilder.Entity<Salon>().HasData(
            new Salon { Id = 1, Name = "Salon A", WorkingHours = "09:00 - 18:00" },
            new Salon { Id = 2, Name = "Salon B", WorkingHours = "10:00 - 19:00" }
        );

        modelBuilder.Entity<Service>().HasData(
            new Service { Id = 1, Name = "Saç Kesimi", Price = 100, DurationMinutes = 30, SalonId = 1 },
            new Service { Id = 2, Name = "Saç Boyama", Price = 150, DurationMinutes = 60, SalonId = 1 }
        );

        modelBuilder.Entity<Employee>().HasData(
            new Employee { Id = 1, Name = "Ahmet", WorkingHours = "09:00 - 18:00", SalonId = 1 },
            new Employee { Id = 2, Name = "Ayşe", WorkingHours = "09:00 - 18:00", SalonId = 1 }
        );

        modelBuilder.Entity<Expertise>().HasData(
            new Expertise { Id = 1, Area = "Saç Kesimi", EmployeeId = 1 },
            new Expertise { Id = 2, Area = "Saç Boyama", EmployeeId = 2 }
        );
    }


        
    }

