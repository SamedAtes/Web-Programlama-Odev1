﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

using SalonManagementSystem.Models;


public class AppointmentController : Controller
{
    private readonly ApplicationDbContext _context;

    public AppointmentController(ApplicationDbContext context)
    {
        _context = context;
    }

    // GET: Randevu Oluşturma Sayfası
    public IActionResult CreateAppointment()
    {
        var viewModel = new AppointmentViewModel
        {
            Salons = _context.Salons.Select(s => new SelectListItem
            {
                Value = s.Id.ToString(),
                Text = s.Name
            }).ToList()
        };

        return View(viewModel);
    }

    // Salon Seçildikten Sonra Hizmetleri Getirme
    public IActionResult GetServicesBySalon(int salonId)
    {
        var services = _context.Services
            .Where(s => s.SalonId == salonId)
            .Select(s => new SelectListItem
            {
                Value = s.Id.ToString(),
                Text = s.Name
            }).ToList();

        return Json(services);
    }

    // Hizmet Seçildikten Sonra Personel Seçimi
    public IActionResult GetEmployeesByService(int serviceId)
    {
        var employees = _context.Employees
            .Where(e => e.Expertises.Any(ex => ex.Id == serviceId))
            .Select(e => new SelectListItem
            {
                Value = e.Id.ToString(),
                Text = e.Name
            }).ToList();

        return Json(employees);
    }

    // POST: Randevu Oluşturma İşlemi
    [HttpPost]
    public IActionResult CreateAppointment(AppointmentViewModel model)
    {
        if (ModelState.IsValid)
        {
            var appointment = new Appointment
            {
                Date = model.SelectedDate,  // Randevu tarihi
                Service = _context.Services.FirstOrDefault(s => s.Id == model.SelectedServiceId)?.Name,  // Hizmet adı
                Price = _context.Services.FirstOrDefault(s => s.Id == model.SelectedServiceId)?.Price ?? 0,  // Hizmet ücreti (nullable ise 0)
                EmployeeId = model.SelectedEmployeeId  // Personel ID
            };

            _context.Appointments.Add(appointment);
            _context.SaveChanges();

            return RedirectToAction("Index");  // Başarılı bir şekilde kaydedildikten sonra başka bir sayfaya yönlendir
        }

        return View(model);  // Eğer model geçerli değilse, formu tekrar göster
    }
}
