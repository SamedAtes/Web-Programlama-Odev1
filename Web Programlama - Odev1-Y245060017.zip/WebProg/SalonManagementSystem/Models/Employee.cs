﻿namespace SalonManagementSystem.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string WorkingHours { get; set; }

        public int SalonId { get; set; }
        public Salon Salon { get; set; }
        public ICollection<Expertise> Expertises { get; set; }
    }
}
