﻿namespace SalonManagementSystem.Models
{
    public class Expertise
    {
        public int Id { get; set; }
        public string Area { get; set; }

        public int EmployeeId { get; set; }
        public Employee Employee { get; set; }
    }

}
