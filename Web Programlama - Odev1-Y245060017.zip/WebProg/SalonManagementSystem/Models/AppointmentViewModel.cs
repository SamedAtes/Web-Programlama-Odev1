﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;

public class AppointmentViewModel
{
    public int SelectedSalonId { get; set; } // Kullanıcının seçtiği salon
    public int SelectedServiceId { get; set; } // Kullanıcının seçtiği hizmet
    public int SelectedEmployeeId { get; set; } // Kullanıcının seçtiği personel
    public DateTime SelectedDate { get; set; } // Randevu tarihi

    public List<SelectListItem> Salons { get; set; } // Dropdown için salonlar
    public List<SelectListItem> Services { get; set; } // Dropdown için hizmetler
    public List<SelectListItem> Employees { get; set; } // Dropdown için çalışanlar
}
